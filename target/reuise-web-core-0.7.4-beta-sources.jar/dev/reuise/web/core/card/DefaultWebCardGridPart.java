package dev.reuise.web.core.card;
import dev.reuise.core.ComponentPart;
import dev.reuise.core.ComponentType;
import dev.reuise.core.CoreComponent;
import dev.reuise.core.CoreComponentOptions;
import dev.reuise.core.Html;
import dev.reuise.core.Interaction;
import dev.reuise.core.RootComponent;
import dev.reuise.core.ScreenSizeValues;
import dev.reuise.core.State;
import dev.reuise.core.card.CardGridPositionMode;
import dev.reuise.core.card.CoreCardGridPart;
import dev.reuise.core.card.DefaultCoreCardGridPart;
import dev.reuise.core.layout.BackdropFilter;
import dev.reuise.core.option.OptionApplicator;
import dev.reuise.core.theme.Theme;
import dev.reuise.web.core.WebComponentFactory;
import dev.reuise.web.core.WebComponentPart;
import dev.reuise.web.core.basecomponent.WebBaseComponentPart;
import dev.reuise.web.core.layout.WebContainer;
import dev.reuise.web.core.layout.WebContainerPart;
import dev.reuise.web.core.parentcomponent.WebParentComponentPart;
import dev.reuise.webstyles.Style;
import dev.reuise.webstyles.StyleBuilder;
import dev.reuise.webstyles.StyleSheetFactory;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
// Option: Padding - CORE
// Option: PaddingTop - CORE
// Option: PaddingRight - CORE
// Option: PaddingBottom - CORE
// Option: PaddingLeft - CORE
// Option: Position - CORE
// Option: Inset - CORE
// Option: BackdropFilter - CORE
// Option: Children - CORE
// Option: Id - WEB
// Option: TagName - WEB
// Option: XmlNamespace - WEB
// Option: Tooltip - WEB
// Option: BaseStyleClass - WEB
// Option: Attributes - WEB
// Option: StyleClasses - WEB
// Option: Data - WEB
// Option: Style - WEB
// Option: InlineStyle - WEB
// Option: Rehydration - WEB
// Option: ContentEditable - WEB
// Option: StoreInElementOptions - WEB
// Option: Mounted - CORE
// Option: Margin - CORE
// Option: MarginTop - CORE
// Option: MarginRight - CORE
// Option: MarginBottom - CORE
// Option: MarginLeft - CORE
// Option: Width - CORE
// Option: MinWidth - CORE
// Option: MaxWidth - CORE
// Option: Height - CORE
// Option: MinHeight - CORE
// Option: MaxHeight - CORE
// Option: RequiredLayoutComponent - CORE
// Option: Parent - CORE
// Option: Wrapper - CORE
// Option: Theme - CORE
// Option: Visible - CORE
// Option: Enabled - CORE
// Option: Focused - CORE
// Option: Debug - CORE
// Option: DebugId - CORE
// base comp: container
// add composition for container: addHeading
// add composition for container: addDivider
// add composition for container: addParagraph
// base comp: parentComponent
// base comp: baseComponent
// add composition for baseComponent: isRehydrated
// add composition for baseComponent: getComputedStyle
// add composition for baseComponent: addOrRemoveStyleClass
// add composition for baseComponent: hasStyleClass
// add composition for baseComponent: removeStyleClass
// add composition for baseComponent: setAttribute
// add composition for baseComponent: removeAttribute
// add composition for baseComponent: getAttribute
// add composition for baseComponent: hasAttribute
// add composition for baseComponent: setData
// add composition for baseComponent: getData
// add composition for baseComponent: hasData
// add composition for baseComponent: setAria
// add composition for baseComponent: getAria
// add composition for baseComponent: hasAria
// add composition for baseComponent: getUniqueId
// add composition for baseComponent: getUniqueStyleClass
// add composition for baseComponent: getStyleSheetId
// add composition for baseComponent: getStyleStates
// add composition for baseComponent: setStyleSheetFactory
// add composition for baseComponent: getStyle
// add composition for baseComponent: hasWrapper
// add composition for baseComponent: isInitialized
// add composition for baseComponent: log
// add composition for baseComponent: removeFromParent
public abstract class DefaultWebCardGridPart<S extends DefaultWebCardGridPart<S, O>, O extends WebCardGridPartOptions> extends DefaultCoreCardGridPart<S, O> implements WebCardGrid , WebComponentPart {
    @Override
    public void showScrim(Boolean show) {
        ((WebContainer) (this.scrim)).addOrRemoveStyleClass("reuise-cardgrid_scrim--visible", show);
    }

    @Override
    public S setPositionMode(CardGridPositionMode positionMode) {
        if (positionMode == null) {
            removePositionModeStyleClass();
            return self();
        }
        for (CardGridPositionMode m : CardGridPositionMode.values()) {
            addOrRemoveStyleClass(createPositionModeStyleClassName(m), positionMode == m);
        }
        return self();
    }

    @Override
    public CardGridPositionMode getPositionMode() {
        for (CardGridPositionMode m : CardGridPositionMode.values()) {
            if (hasStyleClass(createPositionModeStyleClassName(m)))
                return m;

        }
        return null;
    }

    private void removePositionModeStyleClass() {
        for (CardGridPositionMode m : CardGridPositionMode.values())
            removeStyleClass(createPositionModeStyleClassName(m));

    }

    private String createPositionModeStyleClassName(CardGridPositionMode positionMode) {
        return (getBaseStyleClass() + "--positionmode_") + positionMode.getShortName();
    }

    @Override
    public boolean isAnimationEnabled() {
        return hasStyleClass(createAnimationEnabledStyleClassName());
    }

    @Override
    public CoreCardGridPart setAnimationEnabled(Boolean animationEnabled) {
        addOrRemoveStyleClass(createAnimationEnabledStyleClassName(), animationEnabled);
        return self();
    }

    private String createAnimationEnabledStyleClassName() {
        return getBaseStyleClass() + "--animationEnabled";
    }

    private WebContainerPart containerPart;

    private WebParentComponentPart parentComponentPart;

    private WebBaseComponentPart baseComponentPart;

    protected DefaultWebCardGridPart(O options) {
        super(options);
    }

    protected void setupReferences() {
        // Parts
        containerPart = getContainerPart();
        parentComponentPart = getParentComponentPart();
        baseComponentPart = getBaseComponentPart();
        super.setupReferences();
    }

    @Override
    public S setBackdropFilter(BackdropFilter backdropFilter, Object value) {
        this.containerPart.setBackdropFilter(backdropFilter, value);
        return self();
    }

    public S addHeading(int level, String text) {
        containerPart.addHeading(level, text);
        return self();
    }

    public S addHeading(String text) {
        containerPart.addHeading(text);
        return self();
    }

    public S addHeading(int level, Html html) {
        containerPart.addHeading(level, html);
        return self();
    }

    public S addHeading(Html html) {
        containerPart.addHeading(html);
        return self();
    }

    public S addDivider() {
        containerPart.addDivider();
        return self();
    }

    public S addDivider(String label) {
        containerPart.addDivider(label);
        return self();
    }

    public S addParagraph(String text) {
        containerPart.addParagraph(text);
        return self();
    }

    public S addParagraph(Html html) {
        containerPart.addParagraph(html);
        return self();
    }

    @Override
    public RootComponent getRootComponent() {
        return containerPart.getRootComponent();
    }

    @Override
    public void setRootComponent(RootComponent rootComponent) {
        super.setRootComponent(rootComponent);
        this.containerPart.setRootComponent(rootComponent);
        if (scrim != null)
            scrim.setRootComponent(rootComponent);

        if (cardContainer != null)
            cardContainer.setRootComponent(rootComponent);

    }

    @Override
    public Theme getTheme() {
        return containerPart.getTheme();
    }

    @Override
    public S setTheme(Theme theme) {
        super.setTheme(theme);
        if (scrim != null)
            scrim.setTheme(theme);

        if (cardContainer != null)
            cardContainer.setTheme(theme);

        this.containerPart.setTheme(theme);
        return self();
    }

    @Override
    public String getId() {
        return baseComponentPart.getId();
    }

    @Override
    public S setId(String id) {
        this.baseComponentPart.setId(id);
        return self();
    }

    @Override
    public String getTagName() {
        return baseComponentPart.getTagName();
    }

    @Override
    public S setTagName(String tagName) {
        this.baseComponentPart.setTagName(tagName);
        return self();
    }

    @Override
    public String getXmlNamespace() {
        return baseComponentPart.getXmlNamespace();
    }

    @Override
    public S setXmlNamespace(String xmlNamespace) {
        this.baseComponentPart.setXmlNamespace(xmlNamespace);
        return self();
    }

    @Override
    public String getTooltip() {
        return baseComponentPart.getTooltip();
    }

    @Override
    public S setTooltip(String tooltip) {
        this.baseComponentPart.setTooltip(tooltip);
        return self();
    }

    @Override
    public String getBaseStyleClass() {
        return baseComponentPart.getBaseStyleClass();
    }

    @Override
    public S setBaseStyleClass(String baseStyleClass) {
        this.baseComponentPart.setBaseStyleClass(baseStyleClass);
        return self();
    }

    @Override
    public Map<String, String> getAttributes() {
        return baseComponentPart.getAttributes();
    }

    @Override
    public S setAttributes(Map<String, String> attributes) {
        this.baseComponentPart.setAttributes(attributes);
        return self();
    }

    @Override
    public List<String> getStyleClasses() {
        return baseComponentPart.getStyleClasses();
    }

    @Override
    public S setStyleClasses(List<String> styleClasses) {
        this.baseComponentPart.setStyleClasses(styleClasses);
        return self();
    }

    @Override
    public S addStyleClass(String styleClass) {
        this.baseComponentPart.addStyleClass(styleClass);
        return self();
    }

    @Override
    public S setStyleClass(String styleClass) {
        baseComponentPart.setStyleClass(styleClass);
        return self();
    }

    @Override
    public S setStyleClasses(String... styleClasses) {
        baseComponentPart.setStyleClasses(styleClasses);
        return self();
    }

    @Override
    public Map<String, String> getData() {
        return baseComponentPart.getData();
    }

    @Override
    public S setData(Map<String, String> data) {
        this.baseComponentPart.setData(data);
        return self();
    }

    @Override
    public Style getStyle() {
        return baseComponentPart.getStyle();
    }

    @Override
    public S setStyle(Style style) {
        this.baseComponentPart.setStyle(style);
        return self();
    }

    @Override
    public S setStyle(Style style, State state) {
        this.baseComponentPart.setStyle(style, state);
        return self();
    }

    @Override
    public S setStyleAllStates(Style style) {
        setStyle(ScreenSizeValues.of(style, style));
        setStyle(style);
        return self();
    }

    @Override
    public S setStyle(ScreenSizeValues<Style> style) {
        this.baseComponentPart.setStyle(style);
        return self();
    }

    @Override
    public Style getStyle(State state) {
        return baseComponentPart.getStyle(state);
    }

    @Override
    public Style getInlineStyle() {
        return baseComponentPart.getInlineStyle();
    }

    @Override
    public S setInlineStyle(Style inlineStyle) {
        this.baseComponentPart.setInlineStyle(inlineStyle);
        return self();
    }

    @Override
    public String getRehydration() {
        return baseComponentPart.getRehydration();
    }

    @Override
    public S setRehydration(String rehydration) {
        this.baseComponentPart.setRehydration(rehydration);
        return self();
    }

    @Override
    public boolean isContentEditable() {
        return baseComponentPart.isContentEditable();
    }

    @Override
    public S setContentEditable(Boolean contentEditable) {
        this.baseComponentPart.setContentEditable(contentEditable);
        return self();
    }

    @Override
    public List<String> getStoreInElementOptions() {
        return baseComponentPart.getStoreInElementOptions();
    }

    @Override
    public S setStoreInElementOptions(List<String> storeInElementOptions) {
        this.baseComponentPart.setStoreInElementOptions(storeInElementOptions);
        return self();
    }

    @Override
    public S addStoreInElementOptions(String storeInElementOptions) {
        this.baseComponentPart.addStoreInElementOptions(storeInElementOptions);
        return self();
    }

    @Override
    public S setStoreInElementOptions(String storeInElementOptions) {
        baseComponentPart.setStoreInElementOptions(storeInElementOptions);
        return self();
    }

    @Override
    public S removeStoreInElementOptions(String storeInElementOptions) {
        baseComponentPart.removeStoreInElementOptions(storeInElementOptions);
        return self();
    }

    @Override
    public boolean hasStoreInElementOptions(String storeInElementOptions) {
        return baseComponentPart.hasStoreInElementOptions(storeInElementOptions);
    }

    @Override
    public S setRehydration(String rehydration, Boolean canFail) {
        this.baseComponentPart.setRehydration(rehydration, canFail);
        return self();
    }

    @Override
    public S setRehydration(String selector, CoreComponent parent) {
        this.baseComponentPart.setRehydration(selector, parent);
        return self();
    }

    @Override
    public S setRehydration(String selector, CoreComponent parent, Boolean canFail) {
        this.baseComponentPart.setRehydration(selector, parent, canFail);
        return self();
    }

    public boolean isRehydrated() {
        if (containerPart == null)
            return false;

        return containerPart.isRehydrated();
    }

    public Style getComputedStyle() {
        return containerPart.getComputedStyle();
    }

    public S addOrRemoveStyleClass(String styleClass, boolean add) {
        containerPart.addOrRemoveStyleClass(styleClass, add);
        return self();
    }

    public boolean hasStyleClass(String styleClass) {
        return containerPart.hasStyleClass(styleClass);
    }

    public S removeStyleClass(String styleClass) {
        containerPart.removeStyleClass(styleClass);
        return self();
    }

    public S setAttribute(String attribute, String value) {
        containerPart.setAttribute(attribute, value);
        return self();
    }

    public S setAttribute(String attribute) {
        containerPart.setAttribute(attribute);
        return self();
    }

    public S removeAttribute(String attribute) {
        containerPart.removeAttribute(attribute);
        return self();
    }

    public String getAttribute(String attribute) {
        return containerPart.getAttribute(attribute);
    }

    public boolean hasAttribute(String attribute) {
        return containerPart.hasAttribute(attribute);
    }

    public S setData(String data, String value) {
        containerPart.setData(data, value);
        return self();
    }

    public String getData(String data) {
        return containerPart.getData(data);
    }

    public boolean hasData(String data) {
        return containerPart.hasData(data);
    }

    public S setAria(String attribute, String value) {
        containerPart.setAria(attribute, value);
        return self();
    }

    public String getAria(String attribute) {
        return containerPart.getAria(attribute);
    }

    public boolean hasAria(String attribute) {
        return containerPart.hasAria(attribute);
    }

    public String getUniqueId() {
        return containerPart.getUniqueId();
    }

    public String getUniqueStyleClass() {
        return containerPart.getUniqueStyleClass();
    }

    public String getStyleSheetId() {
        return containerPart.getStyleSheetId();
    }

    public String getStyleSheetId(State state) {
        return containerPart.getStyleSheetId(state);
    }

    public Set<State> getStyleStates() {
        return containerPart.getStyleStates();
    }

    public void setStyleSheetFactory(StyleSheetFactory styleSheetFactory) {
        containerPart.setStyleSheetFactory(styleSheetFactory);
    }

    public Style getStyle(State state, Interaction interaction) {
        return containerPart.getStyle(state, interaction);
    }

    public Style getStyle(Interaction interaction) {
        return containerPart.getStyle(interaction);
    }

    public boolean hasWrapper() {
        return containerPart.hasWrapper();
    }

    public boolean isInitialized() {
        return containerPart.isInitialized();
    }

    public void log(Object obj) {
        containerPart.log(obj);
    }

    public void removeFromParent() {
        containerPart.removeFromParent();
    }

    @Override
    public WebComponentFactory getComponentFactory() {
        return ((WebComponentFactory) (baseComponentPart.getComponentFactory()));
    }

    @Override
    public void addPart(ComponentPart.Type type, ComponentPart part) {
        baseComponentPart.addPart(type, part);
    }

    @Override
    public <C extends ComponentType<?, T>, T extends CoreComponentOptions> void initialize(C component, T options) {
        setupReferences();
        baseComponentPart.initialize(component, options);
    }

    @Override
    public WebCardGrid getComponent() {
        return ((WebCardGrid) (baseComponentPart.getComponent()));
    }

    public boolean onPreInitialize(O options) {
        if (!super.onPreInitialize(options))
            return false;

        setupReferences();
        return true;
    }

    public void onInitialize(O options) {
        super.onInitialize(options);
    }

    // Implementation
    // Implementation
    public void onCreate(O options) {
        super.onCreate(options);
        WebContainer webCardContainer = ((WebContainer) (this.cardContainer));
        webCardContainer.getStyle().setWidth("100%");
        if (!isRehydrated()) {
            this.columnGap.entrySet().forEach(e -> {
                webCardContainer.setPaddingLeft(e.getValue(), e.getKey());
                webCardContainer.setPaddingRight(e.getValue(), e.getKey());
                webCardContainer.getStyle(e.getKey()).setColumnGap(e.getValue());
            });
            this.rowGap.entrySet().forEach(e -> {
                webCardContainer.setPaddingTop(e.getValue(), e.getKey());
                webCardContainer.setPaddingBottom(e.getValue(), e.getKey());
                webCardContainer.getStyle(e.getKey()).setRowGap(e.getValue());
            });
        }
    }

    public void applyOptions(O options, OptionApplicator applicator, Collection<State> states) {
        super.applyOptions(options, applicator, states);
    }

    public void onInitializeComponentType(RootComponent rootComponent) {
        super.onInitializeComponentType(rootComponent);
        containerPart.onInitializeComponentType(rootComponent);
    }

    @Override
    public WebContainer getScrim() {
        return ((WebContainer) (super.getScrim()));
    }

    @Override
    public WebContainer getCardContainer() {
        return ((WebContainer) (super.getCardContainer()));
    }

    // Implementation
    // Implementation
    public void onInitializeCommonStyle(StyleBuilder commonStyles) {
        commonStyles.addRule(".reuise-cardgrid").setWidth("inherit").setMinWidth("100%").setHeight("inherit").setOverflow("auto");
        commonStyles.addRule(".reuise-cardgrid--positionmode_absolute .reuise-card").setPosition("absolute");
        commonStyles.addRule(".reuise-cardgrid:not(.reuise-cardgrid--positionmode_absolute) .reuise-cardgrid_cardcontainer").setDisplay("flex").setFlexWrap("wrap").setBoxSizing("border-box");
        commonStyles.addRule(".reuise-cardgrid--positionmode_absolute .reuise-cardgrid_cardcontainer").setPosition("relative");
        commonStyles.addRule(".reuise-cardgrid_card").setTransition("all 200ms ease-in-out");
        commonStyles.addRule(".reuise-cardgrid_card--hidden").setOpacity("0");
        commonStyles.addRule(".reuise-cardgrid_scrim--visible").setOpacity("1").setCursor("pointer").setPointerEvents("all").setZIndex(1);
        commonStyles.addRule(".reuise-cardgrid_scrim").setPosition("absolute").setBackground("#00000026").setTop("0").setRight("0").setBottom("0").setLeft("0").setOpacity(0).setPointerEvents("none").setTransition("opacity 100ms ease-in-out");
    }

    @Override
    public S setColumnGapAllStates(Integer columnGap) {
        setColumnGap(ScreenSizeValues.of(columnGap, columnGap));
        setColumnGap(columnGap);
        return self();
    }

    @Override
    public S setRowGapAllStates(Integer rowGap) {
        setRowGap(ScreenSizeValues.of(rowGap, rowGap));
        setRowGap(rowGap);
        return self();
    }

    @Override
    public S setGapAllStates(Integer gap) {
        setGap(ScreenSizeValues.of(gap, gap));
        setGap(gap);
        return self();
    }

    @Override
    public S setCardWidthAllStates(Integer cardWidth) {
        setCardWidth(ScreenSizeValues.of(cardWidth, cardWidth));
        setCardWidth(cardWidth);
        return self();
    }

    @Override
    public S setCardHeightAllStates(Integer cardHeight) {
        setCardHeight(ScreenSizeValues.of(cardHeight, cardHeight));
        setCardHeight(cardHeight);
        return self();
    }
}